print('hello world')

# py -m venv env
# env/Scripts/activate